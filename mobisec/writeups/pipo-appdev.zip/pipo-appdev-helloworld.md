# Solution

## Description of the problem

The helloworld challenge requires to develop an app that prints a specific string with a specific verbosity and tag using Android's Logging API.

## Solution

I've solved the challenge by developing an app. First, import the logging library "android.util.Log", and then start logging with `Log.v` using the tag *MOBISEC".

